"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import list_subtraction
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


minuend = input("A list of values: ")
minuend = [int(x) for x in minuend.split(',')]
subtrahend = input("A list of values to not include in difference: ")
subtrahend = [int(x) for x in subtrahend.split(',')]


print(f"list_subtraction({minuend}, {subtrahend})")
list_subtraction(minuend, subtrahend)
print(minuend)
