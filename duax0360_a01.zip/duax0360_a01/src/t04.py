"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import file_analyze
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


fv = input('An already open file reference: ')
with open(fv, 'r') as file:
    upper, lower, digits, whitespace, remaining = file_analyze(file)
print()
print("Uppercase:", upper)
print("Lowercase:", lower)
print("Digits:", digits)
print("Whitespace:", whitespace)
print("Remaining:", remaining)
