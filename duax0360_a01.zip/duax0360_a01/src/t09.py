"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-13"
-------------------------------------------------------
"""
# Imports
from functions import matrixes_add
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


a = [[0, 2], [3, 3], [4, 10]]
b = [[6, 7], [8, 9], [1, 1]]

print(f"matrixes_add({a},{b})")
print(matrixes_add(a, b))
