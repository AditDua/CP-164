"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-20"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import by_origin
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


food = Food("Grape", 3, True, 2)
food1 = Food("Chicken", 2, False, 1)
food2 = Food("Sushi", 3, True, 12)
foods = [food, food1, food2]
print(food)
print(food1)
print(food2)
print()
print(f"By origin: ")
o_foods = by_origin(foods, 3)
for s in o_foods:
    print(s)
