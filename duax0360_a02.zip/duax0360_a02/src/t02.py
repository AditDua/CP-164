"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-20"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import average_calories
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


food = Food("Apple", 3, True, 10)
food1 = Food("Fish", 2, False, 32)
food2 = Food("Taco", 3, True, 100)
foods = [food, food1, food2]
print(food)
print(food1)
print(food2)
print()
avg = average_calories(foods)
print(f"Average Calories: {avg}")
