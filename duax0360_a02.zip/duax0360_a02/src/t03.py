"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-20"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import calories_by_origin
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


food = Food("Pasta", 7, True, 172)
food1 = Food("Burger", 7, False, 100)
food2 = Food("Taco", 6, True, 100)
food3 = Food("Nacho", 6, True, 56)
foods = [food, food1, food2, food3]
print(food)
print(food1)
print(food2)
print(food3)
print()
by_origin = calories_by_origin(foods, 6)
print(f"Average Calories by origin: {by_origin}")
