"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-20"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import food_search
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


food = Food("Apple", 5, True, 5)
food1 = Food("Chicken", 2, False, 67)
food2 = Food("Pepsi", 3, True, 12)
food3 = Food("Taco", 3, False, 100)
foods = [food, food1, food2, food3]
result = food_search(foods, -1, 0, True)
print(food)
print(food1)
print(food2)
print(food3)
print()
print("Food Search: ")
for f in result:
    print(f)
