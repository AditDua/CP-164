"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-27"
-------------------------------------------------------
"""
# Imports
from functions import stack_combine
from Stack_array import Stack
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source1 = Stack()
source2 = Stack()

l = [8, 12, 8, 5]
for v in l:
    source1.push(v)
l2 = [14, 9, 7, 1, 6, 3]
for x in l2:
    source2.push(x)
print(f'Source1: {l}')
print(f'Source2: {l2}')
target = stack_combine(source1, source2)
for t in target:
    print(t)
