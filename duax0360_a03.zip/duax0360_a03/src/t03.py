"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-27"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from functions import stack_reverse
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source_stack = Stack()


for value in [1, 2, 3, 4, 5]:
    source_stack.push(value)


print("Original source stack:")
original_stack = Stack()
while not source_stack.is_empty():
    value = source_stack.pop()
    original_stack.push(value)
    print(value)


print("\nReversed source stack:")
while not original_stack.is_empty():
    print(original_stack.pop())

stack_reverse(original_stack)
