"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-03"
-------------------------------------------------------
"""
# Imports
from Queue_circular import Queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


queue1 = Queue()
queue1.insert(1)
queue1.insert(2)
queue1.insert(3)

queue2 = Queue()
queue2.insert(1)
queue2.insert(2)
queue2.insert(3)

equals = queue1 == queue2
print("Are the queues equal?", equals)

queue = Queue(3)

print(len(queue))

print(queue.is_empty())

queue.insert(100)

print(len(queue))

value = queue.peek()

print(value)

removed = queue.remove()

print(removed)


queue.insert(100)
queue.insert(200)
queue.insert(300)
print(queue.is_full())
