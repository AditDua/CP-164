"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-03"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source = Queue()

source.insert(4)

source.insert(5)

source.insert(6)

target1, target2 = source.split_alt()


print("Target 1: ")
while len(target1) > 0:
    print(target1.remove())

print("Target 2:")
while len(target2) > 0:
    print(target2.remove())
