"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-10"
-------------------------------------------------------
"""
# Imports
from List_array import List
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


lst5 = List()
lst5.insert(0, 1)
lst5.insert(1, 2)
lst5.insert(2, 3)

lst6 = List()
lst6.insert(0, 1)
lst6.insert(1, 2)
lst6.insert(2, 3)


equals = lst5 == lst6
print("Are the queues equal?", equals)

lst = List()
lst.insert(0, 100)

lst.insert(1, 200)

lst.insert(2, 200)

lst.clean()


print()

for value in lst:
    print(value)


print()

print(100 in lst)


lst.insert(4, 100)


print()

print(lst.count(100))


print()

print(lst.find(100))


print()
print(lst[2])


print()

print(lst.index(100))


lst2 = List()


lst2.insert(0, 100)

lst2.insert(1, 1000)


lst3 = List()


lst3.intersection(lst, lst2)


print()

for value in lst3:
    print(value)


print()

print(lst2.max())


print()

print(lst2.min())


print()

print(lst.peek())


lst2.remove(100)


print()

for value in lst2:
    print(value)


lst.remove_front()


print()

for value in lst:
    print(value)


lst4 = List()


lst4.insert(0, 11)

lst4.insert(1, 22)

lst4.insert(2, 22)

lst4.remove_many(22)


print()

for value in lst4:
    print(value)


lst4.insert(3, 1000)

lst4.insert(4, 100)


target1, target2 = lst4.split()


print()

for value in target1:
    print(value)


print()

for value in target2:
    print(value)


target1.insert(0, 1000)

target1.insert(1, 100000)


target3, target4 = target1.split_alt()


print()

for value in target3:
    print(value)


print()

for value in target4:
    print(value)


target1.union(target3, target4)


print()
for value in target3:
    print(value)
