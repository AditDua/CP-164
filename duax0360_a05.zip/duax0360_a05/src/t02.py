"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-10"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


lst = Sorted_List()


lst.insert(100)

lst.insert(200)

lst.insert(200)

lst.clean()


print()

for value in lst:
    print(value)


print()

print(100 in lst)


lst.insert(100)


print()

print(lst.count(100))


print()

print(lst.find(100))


print()
print(lst[2])


print()

print(lst.index(100))


lst2 = Sorted_List()


lst2.insert(100)

lst2.insert(1000)


lst3 = Sorted_List()


lst3.intersection(lst, lst2)


print()

for value in lst3:
    print(value)


print()

print(lst2.max())


print()

print(lst2.min())


print()

print(lst.peek())


lst2.remove(100)


print()

for value in lst2:
    print(value)


lst.remove_front()


print()

for value in lst:
    print(value)


lst4 = Sorted_List()


lst4.insert(11)

lst4.insert(22)

lst4.insert(22)

lst4.remove_many(22)


print()

for value in lst4:
    print(value)


lst4.insert(1000)

lst4.insert(100)


target1, target2 = lst4.split()


print()

for value in target1:
    print(value)


print()

for value in target2:
    print(value)


target1.insert(1000)

target1.insert(100000)


target3, target4 = target1.split_alt()


print()

for value in target3:
    print(value)


print()

for value in target4:
    print(value)


target3.insert(100)

target3.insert(100000)


target5, target6 = target3.split_key(10000)


print()

for value in target5:
    print(value)


print()

for value in target6:
    print(value)


target3.union(target5, target6)


print()
for value in target3:
    print(value)
