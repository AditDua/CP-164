"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-16"
-------------------------------------------------------
"""
# Imports

# Constants


from BST_linked import BST


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


tree = BST()
tree.insert(5)
tree.insert(6)
tree.insert(3)
tree.insert(1)
tree.insert(4)
tree.insert(8)


'''
print(tree.is_valid())
tree._root._right._value = 4
print(tree.is_valid())
'''
'''
tree2 = BST()
for i in range(1,7):
    tree2.insert(i)
'''
print(tree.levelorder())
tree.remove(3)
print(tree.levelorder())
