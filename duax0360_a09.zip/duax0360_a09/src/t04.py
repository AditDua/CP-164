"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-23"
-------------------------------------------------------
"""
# Imports

# Constants


from BST_linked import BST


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


bst = BST()

arr = [11, 7, 15, 6, 9, 12, 18, 8]

for value in arr:
    bst.insert(value)

zero, one, two = bst.node_counts()


print(zero)


print(one)


print(two)


print(15 in bst)


print(bst.parent(15))

print(bst.parent_r(8))
