"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-27"
-------------------------------------------------------
"""
# Imports

# Constants


from Sorts_array import Sorts


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


a = [9999999, 12, 1, 120, 19, 2, 123120]

Sorts.radix_sort(a)

print(a)
