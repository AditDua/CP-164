"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-27"
-------------------------------------------------------
"""
# Imports

# Constants

from Sorts_List_linked import Sorts
from List_linked import List


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


lst = List()

lst.append(9999)
lst.append(12)
lst.append(1)
lst.append(120)
lst.append(19)
lst.append(0)

Sorts.radix_sort(lst)

for i in lst:
    print(i)
