"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-11"
-------------------------------------------------------
"""
# Imports
from Food import Food
from Food_utilities import write_foods
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


fv = open("new_foods.txt", "w")

k = Food("Biryani", 2, False, 130)
y = Food("Beaver Tail", 0, True, 500)

l = [k, y]

write_foods(fv, l)
