"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


values = [1, 2, 3, 4]

print("Values: {}".format(values))

s = Stack()

print(">> Is the stack empty?")
empty = s.is_empty()

print("Expect: {}\tGot: {}".format(True, empty))

print(">> Pushing values onto Stack")

for val in values:
    s.push(val)

print("Stack contents: ", end='')
print("Expect: {}\tGot: ".format(values[::-1]), end='')
for elem in s:
    print(elem, end=' ')
print()
print(">> Pop top of stack")
value = s.pop()
print("Expect: {}\tGot: {}".format(values[-1], value))

print(">> Peek the top of the stack")
peeked = s.peek()
print("Expect: {}\tGot: {}".format(values[-2], peeked))
