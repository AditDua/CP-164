"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
from utilities import array_to_stack
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


array = [0, 1, 2, 3, 4]
s = Stack()

print("Array: {}".format(array))

array_to_stack(s, array)

print("Values: {}".format(s._values))
print("Stack to Array: ")
for elem in s:
    print(elem, end=' ')
print()
print("Array: {}".format(array))

print("Top: {}".format(s.peek()))
