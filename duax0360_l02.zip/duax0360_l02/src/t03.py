"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
# Imports
from utilities import stack_to_array
from Stack_array import Stack
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


target = []
array = [1, 2, 3, 4]

s = Stack()

for i in array:
    s.push(i)

print("Array before: {}".format(target))
print("Stack before:")
for i in s:
    print(i, end=' ')
print()
stack_to_array(s, target)

print("Array after: {}".format(target))
print("Stack After:")
for i in s:
    print(i, end=' ')
