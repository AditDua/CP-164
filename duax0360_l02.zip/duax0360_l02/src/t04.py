"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-19"
-------------------------------------------------------
"""
# Imports
from utilities import stack_test
from Stack_array import Stack
from random import randint
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source1 = []
source2 = [1]
source3 = [0, 1, 2, 3, 4]
source4 = []
for i in range(5):
    source4.append(randint(0, 5))

print("Test 1: List: {}".format(source1))
stack_test(source1)
print("\nTest 2: List: {}".format(source2))
stack_test(source2)
print("\nTest 3: List: {}".format(source3))
stack_test(source3)
print("\nTest 4: List: {}".format(source4))
stack_test(source4)
