"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-26"
-------------------------------------------------------
"""
# Imports

# Constants


from Priority_Queue_array import Priority_Queue
from utilities import array_to_pq, pq_to_array


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


source = [1, 2, 5, 4, 8, 6, 7, 3, 9]
target = []
q = Priority_Queue()
array_to_pq(q, source)

print(q._values)
