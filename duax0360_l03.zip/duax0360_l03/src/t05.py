"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-01-26"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue
from utilities import array_to_queue
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


q = Queue()
source = [1, 2, 3]
array_to_queue(q, source)
for v in q:
    print(v)
