"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-07"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set
# Constants


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


bag = [4, 5, 3, 4, 5, 2, 2, 4]
s = bag_to_set(bag)
print(s)
