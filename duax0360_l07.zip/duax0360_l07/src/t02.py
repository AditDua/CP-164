"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-28"
-------------------------------------------------------
"""
# Imports

# Constants


from List_linked import List


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


x = [1, 2, 3]

source = List()
target = List()


for i in [22, 33, 11]:
    source.append(i)
    target.append(i)
print(source.is_identical_r(target))
