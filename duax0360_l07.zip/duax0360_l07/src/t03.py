"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-02-28"
-------------------------------------------------------
"""
# Imports

# Constants


from List_linked import List


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


x = [11, 22, 33, 44]
lst = List()

for i in x:
    lst.append(i)

target1, target2 = lst.split_alt_r()


for i in target1:
    print(target1._front._value)
    target1._front = target1._front._next
