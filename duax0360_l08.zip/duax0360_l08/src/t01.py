"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-05"
-------------------------------------------------------
"""
# Imports

# Constants


from morse import ByLetter


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


c1 = ByLetter('B', '-...')

c2 = ByLetter('A', '.-')

print(c1 > c2)
