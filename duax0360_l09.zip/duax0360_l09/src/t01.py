"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Adit Dua
ID:      169070360
Email:   duax0360@mylaurier.ca
__updated__ = "2024-03-14"
-------------------------------------------------------
"""
# Imports

# Constants

from Hash_Set_array import Hash_Set
from functions import hash_table
from Food_utilities import read_foods


def func():
    """
    -------------------------------------------------------
    description
    Use: 
    -------------------------------------------------------
    Parameters:
        name - description (type)
    Returns:
        name - description (type)
    ------------------------------------------------------
    """


fv = "foods.txt"
f = open(fv, "r", encoding="utf-8")
foods = read_foods(f)
hash_table(7, foods)
f.close()

h = Hash_Set(5)
l = [99, 11, 22, 33]
for f in l:
    h.insert(f)
h.debug()
