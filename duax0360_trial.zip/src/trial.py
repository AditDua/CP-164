"""
-------------------------------------------------------
Midterm Trial
-------------------------------------------------------
Author: Adit Dua
ID:     169070360
Email:  duax0360@mylaurier.ca
__updated__ = "2023-06-12"
-------------------------------------------------------
"""
print("Congratulations, you imported this project correctly.")
